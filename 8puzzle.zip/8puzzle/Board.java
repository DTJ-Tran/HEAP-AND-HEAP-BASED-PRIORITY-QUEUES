import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Board {

    private final int[][] tiles;
    private int blankRow = - 1;
    private int blankCol = - 1;

    public Board(int[][] tiles){
    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)

        if (tiles == null|| tiles[0].length == 0) 
            throw new IllegalArgumentException("tiles cannot be null");

        this.tiles = tiles;
        int n = tiles.length;

        for (int row = 0; row < n; row ++) {
            if (tiles[row].length != n) {
                throw new IllegalArgumentException("tiles must be n-by-n");
            }

            for (int col = 0; col < n; col++) {
                this.tiles[row][col] = tiles[row][col];
                if (tiles[row][col] == 0) {
                    blankRow = row;
                    blankCol = col;
                }
            }

        }
        
    }
    
    // string representation of this board

    public String toString(){  
        int n = dimension();
        StringBuilder sb = new StringBuilder();
        sb.append(n).append("\n"); // the first line is the dimension of the board
        for (int row = 0; row < n; row++) {
            for (int col=0; col <n; col++) {
                sb.append(String.format("%2d ", tiles[row][col])); // add 2 spaces between each element
            }
            sb.append("\n"); // new line after each row
        }
        return sb.toString();
    
    }
    // board dimension n
    public int dimension(){
        int n = tiles.length;
            return n;
        }
    // number of tiles out of place
    public int hamming(){
        int hammingValue = 0;
        int[][] goal_board = new int[tiles.length][tiles.length];

        for (int row = 0; row <tiles.length; row++) {
            for (int col =0; col < tiles.length; col++){
                goal_board[row][col] = row * tiles.length + col +1;
                goal_board[tiles.length -1][tiles.length -1] = 0;
                if (tiles[row][col] != 0 && tiles[row][col] != goal_board[row][col]) {
                    hammingValue++;
                    
                }
            }
        }
        return hammingValue;
    }
    // sum of Manhattan distances between tiles and goal
    public int manhattan(){
       int manhattan = 0;

       for (int row = 0; row < tiles.length; row++) {
         for (int col =0; col < tiles.length; col++) {
                int value = tiles[row][col];
                if(value != 0){
                    int targetX = (value -1)/ tiles.length;
                    int targetY = (value -1) % tiles.length;
                    int dx = row - targetX; // x (current position) distance to target - the goal
                    int dy = col - targetY; // y (current position) distance to target - the goal
                    manhattan += Math.abs(dx) + Math.abs(dy);
                }
         }
       }
        return manhattan;
    }
    // is this board the goal board?     
    public boolean isGoal(){
        return hamming() == 0;
    }
    // does this board equal y?
    @Override
    public boolean equals (Object y) {
        if (this == y) {
            return true;
        }
        if ( y == null|| y.getClass() != this.getClass())  // The objects are of different types or y is null
            return false;
       
        Board that = (Board) y;
        return Arrays.deepEquals(this.tiles, that.tiles);
    }
    
    //Helper method to perform a deep copy of the 2D array

    private int[][] deepCopy(int[][] original) {
        int[][] copy = new int[original.length][];
        for (int i = 0; i < original.length; i++) {
            copy[i] = Arrays.copyOf(original[i], original[i].length);
        }
        return copy;
    }


    //Helper method to swap two element in the 2D array

    private void swap(int[][] array, int row1 , int col1, int row2, int col2) {
        int temp = array[row1][col1];
        array[row1][col1] = array[row2][col2];
        array[row2][col2] = temp;

    }

    // all neighboring boards
    public Iterable<Board> neighbors(){
        List<Board> neighbors = new ArrayList<>();
        int n = tiles.length;
       
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (this.tiles[row][col]== 0) {
                    blankRow = row;
                    blankCol = col;   
            }
        }
    }
     // Move the empty space up (if possible)
     if(blankRow > 0) {
        int[][] copy = deepCopy(tiles);
        swap(copy, blankRow, blankCol, blankRow -1, blankCol);
        neighbors.add(new Board(copy));
     }

       // Move the empty space down (if possible)
    if (blankRow < n - 1) {
        int[][] copy = deepCopy(tiles);
        swap(copy, blankRow, blankCol, blankRow +1, blankCol);
        neighbors.add(new Board(copy)); 
    }

        // Move the empty space left (if possible)
    if(blankCol > 0) {
        int[][] copy = deepCopy(tiles);
        swap(copy, blankRow, blankCol, blankRow, blankCol -1 );
        neighbors.add(new Board(copy)); 
    }

        // Move the empty space right (if possible)
    if(blankCol < n - 1) {
        int[][] copy = deepCopy(tiles);
        swap(copy, blankRow, blankCol, blankRow, blankCol +1);
        neighbors.add(new Board(copy));
    }
        return neighbors;
       
    }
    // a board that is obtained by exchanging any pair of tiles - the first two non-zero tiles (because they guarantee to be in the wrong position and the results are solvable)
    public Board twin(){
        int [][] copy = deepCopy(tiles);
        
        if (blankRow != 0) { 
            swap(copy, 0, 0, 1, 1);  // swap the first two non-zero tiles in the first row
        } else { 
            swap(copy, 1, 0, 1, 1); } // swap the first two non-zero tiles in the second row

        return new Board(copy);
    }
    // unit testing (not graded)
    public static void main(String[] args){
        int[][] tiles = {
            {6, 1, 2, 3},
            {5, 0, 7, 4},
            {9, 10, 11, 8},
            {13, 14, 15, 12}
        };
    Board board = new Board(tiles);
    
    System.out.println("Board:");
    System.out.println(board);
    
    System.out.println("Dimension: " + board.dimension());
    System.out.println("Hamming: " + board.hamming());
    System.out.println("Manhattan: " + board.manhattan());
    System.out.println("Is goal: " + board.isGoal());
    
    System.out.println("Neighbors:");
    for (Board neighbor : board.neighbors()) {
        System.out.println(neighbor);
    }
    
    System.out.println("Twin:");
    System.out.println(board.twin());
    }

}