
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;


public class Solver {
    
    // Node class

    private static final class Node implements Comparable<Node> {
        Board board; // current board
        int moves; // number of moves made to reach this board
        Node prev; // previous node


        public Node(Board board, int moves, Node prev) {
            this.board = board; // current board
            this.moves = moves; // number of moves made to reach this board
            this.prev = prev; // previous node
    
        }
        
        public Board getBoard() {
            return board;
        }


        public int getMoves() {
            return moves;
        }

        public Node getPrev() {
            return prev;
        }
       public int getPriority()  // using manhattan priority function
       {
            return moves + board.manhattan();
        }

        @Override //
        public int compareTo(Node that) {
            return Integer.compare(this.getPriority(), that.getPriority());
        }

    }
  
    private boolean solvable;
    private int moves;
    private Stack<Board> solution;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException("Null argument");
        }
    
        moves = -1;
        solution = new Stack<>();
        solvable = false;
        
        MinPQ<Node> queue = new MinPQ<>();
        queue.insert(new Node(initial, 0, null)); // initial board

        MinPQ<Node> twinQueue = new MinPQ<>();

        twinQueue.insert(new Node(initial.twin(), 0, null)); // twin of initial board
    
        while (!queue.isEmpty() && !twinQueue.isEmpty()) {

            Node current = queue.delMin(); // delete and return the minimum priority node
            Node twinCurrent = twinQueue.delMin();
    
            if (current.getBoard().isGoal()) {
                    solvable = true;
                    moves = current.getMoves();


    
                    while (current != null) {
                        solution.push(current.getBoard());
                        current = current.getPrev();
                    }
    
                break;
                
            }

            if(twinCurrent.getBoard().isGoal()) {
                break;
            }
    
            for (Board neighbor : current.getBoard().neighbors()) // initial board
            {
                if (current.getPrev() == null || !neighbor.equals(current.getPrev().getBoard())) {
                    queue.insert(new Node(neighbor, current.getMoves() + 1, current));
                }
            }


            for (Board neighbor : twinCurrent.getBoard().neighbors()) // twin of initial board
             {
                if (twinCurrent.getPrev() == null || !neighbor.equals(twinCurrent.getPrev().getBoard())) {
                    twinQueue.insert(new Node(neighbor, twinCurrent.getMoves() + 1, twinCurrent));
                }
            }
        }
    }
    

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return solvable;
    }



    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        return moves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (solvable) {
            return solution;
        } else {
            return null;
        }
        
    }

    // test client (see below) 

 /* 
     // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
 
 */   
 /* { 6,1,2,3 }, { 5 , 0,  7,  4  }, { 9,10,11,8 } , { 13,14,15,12 } */
           
        public static void main(String[] args) {
          /*
        int[][] tiles = { {3,2,4,8}, {1,6,0,12}, {5,10,7,11}, {9,13,14,15} };
        
          */   
    // create initial board from file
            In in = new In(args[0]); // input file
            int n = in.readInt(); // read a integer
            int[][] blocks = new int[n][n]; // create a 2D array
            for (int i = 0; i < n; i++) // read the input file
                for (int j = 0; j < n; j++)
                    blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        Solver solver = new Solver(initial);  

        if (solver.isSolvable()) {
            StdOut.println("Solvable!");
            StdOut.println("Number of moves: " + solver.moves());
            for (Board board : solver.solution()) {
                StdOut.println(board);
            }
        } else {
              StdOut.println("Unsolvable!");
            }
        
    }
}
